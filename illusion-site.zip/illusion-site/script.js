const articleList = document.getElementById("article-list");
const year = document.getElementById("year");
year.textContent = new Date().getFullYear();

articleList.innerHTML = articles.map((article) => {
  const formattedDate = new Date(article.date).toLocaleDateString("en", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });

  const paragraphs = article.body.map((paragraph) => `<p>${paragraph}</p>`).join("");

  return `
    <article class="article-card">
      <div class="article-meta">${formattedDate}</div>
      <h3>${article.title}</h3>
      <div class="article-body">${paragraphs}</div>
      <div class="author">
        <img src="${article.authorPhoto}" alt="${article.authorPhotoAlt}" onerror="this.src='assets/author-placeholder.svg'" />
        <div>
          <span>Written by</span>
          <strong>${article.author}</strong>
        </div>
      </div>
    </article>
  `;
}).join("");
