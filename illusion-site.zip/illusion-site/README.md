# The Inner Pages

A simple static website for weekly reflective articles, ready for GitHub Pages.

## How to add a new article

Open `articles.js` and add a new article object at the top of the `articles` array:

```js
{
  title: "Your New Title",
  date: "2026-05-21",
  author: "Writer Name",
  authorPhoto: "assets/writer-photo.jpg",
  authorPhotoAlt: "Photo of Writer Name",
  body: [
    "First paragraph.",
    "Second paragraph.",
    "Third paragraph."
  ]
},
```

Add writer photos inside the `assets` folder. Keep image names simple, for example `shreyas-kulkarni.jpg`.

## Publish with GitHub Pages

1. Create a GitHub repository named `<your-github-username>.github.io`.
2. Upload these files to the repository.
3. Go to Settings > Pages.
4. Choose Deploy from a branch.
5. Select the `main` branch and `/root`, then save.
6. Visit `https://<your-github-username>.github.io` after GitHub finishes publishing.
