const articles = [
  {
    title: "The Day the Illusion Broke",
    date: "2026-05-14",
    author: "Shreyas Kulkarni",
    authorPhoto: "assets/shreyas-kulkarni.jpg",
    authorPhotoAlt: "Photo of Shreyas Kulkarni",
    body: [
      "I genuinely wish more people pause long enough to see this before spending their whole lives running.",
      "At some point, you begin to question the structure everything was built on, not intellectually, but because somewhere deep inside, you can no longer keep pretending it works. The endless idea that happiness exists on the other side of achievement, identity, or arrival starts feeling hollow, especially when you have already touched things you once thought would finally do it… and they did not.",
      "And when that happens, the world quickly offers substitutes.",
      "More entertainment. More pleasure. More distraction. More places to go. More ways to stay busy.",
      "Not because it wants to free you, but because distraction is easier than disruption.",
      "So you are taught to indulge. Travel more. Consume more. Chase more. Anything, as long as you do not sit still long enough to question why none of it truly touches the emptiness.",
      "And the moment you truly question it, there is no going back.",
      "Not because something goes wrong, but because the illusion begins to crack from within.",
      "First comes suffering. Real suffering. Confusion. Emptiness. The collapse of meanings you once trusted.",
      "Because when the old chase stops making sense, life can feel terrifyingly directionless.",
      "But if you keep looking, if you stay through that collapse instead of escaping it, one day something becomes undeniable:",
      "Thoughts, language, ambition… they were never meant to make you happy.",
      "They are tools for navigating the physical world, nothing more.",
      "You can build through them. Create through them. Achieve through them.",
      "But you can never be happy through them.",
      "And when that truth is no longer just understood, but lived, your entire way of operating changes.",
      "You stop chasing happiness through thought, pleasure, or the next promise.",
      "And for the first time, begin living from something deeper than all of it."
    ]
  }
];
